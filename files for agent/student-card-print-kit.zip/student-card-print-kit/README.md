# Student Card Print Kit

Ready-to-integrate React/TypeScript implementation for the student-card print flow.

Give the whole folder to the coding agent and tell it:

> Copy the files preserving paths, then follow `AGENT_INTEGRATION.md` exactly and wire it into the current `StudentProfilePage.tsx` using the existing QR flow. Do not refactor unrelated code.

The implementation contains the card front/back, PDF creation, PDF-in-modal preview, download, print, cleanup and component tests.
